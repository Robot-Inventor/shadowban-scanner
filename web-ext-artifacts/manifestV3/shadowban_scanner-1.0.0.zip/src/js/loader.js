const script = document.createElement("script");
script.src = chrome.runtime.getURL("src/js/index.js");
script.addEventListener("load", () => {
    script.remove();
    const eventGenerator = document.getElementById("shadowban-scanner-event-generator");
    eventGenerator.addEventListener("newMessage", (event) => {
        const target = event.detail.element;
        const { messageType } = target.dataset;

        const message = chrome.i18n.getMessage(messageType);
        target.insertAdjacentText("afterbegin", message);

        const button = target.querySelector("button");
        button.textContent = chrome.i18n.getMessage("showMore");

        const pre = target.querySelector("pre");
        pre.textContent = chrome.i18n.getMessage(`${messageType}StatusMessage`);
    });
});
document.body.appendChild(script);
